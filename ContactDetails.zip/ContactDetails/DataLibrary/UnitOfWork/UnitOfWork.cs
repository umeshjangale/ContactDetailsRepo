﻿using AutoMapper;
using DataLibrary.Contracts;
using DataLibrary.Repositories;
using System.Threading.Tasks;

namespace DataLibrary.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ContactDbContext contactDbContext;
        private readonly IMapper mapper;
        private IContactsRepository contactsRepository;

        public UnitOfWork(ContactDbContext contactDbContext, IMapper mapper)
        {
            this.contactDbContext = contactDbContext;
            this.mapper = mapper;
        }

        public IContactsRepository ContactsRepository
        {
            get
            {
                if (contactsRepository == null)
                    contactsRepository = new ContactsRepository(contactDbContext, mapper);

                return contactsRepository;
            }
        }

        public async Task SaveChangesAsync()
        {
            await contactDbContext.SaveChangesAsync();
        }
    }
}