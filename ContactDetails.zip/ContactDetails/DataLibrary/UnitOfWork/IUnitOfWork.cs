﻿using DataLibrary.Contracts;
using System.Threading.Tasks;

namespace DataLibrary.UnitOfWork
{
    public interface IUnitOfWork
    {
        Task SaveChangesAsync();
        IContactsRepository ContactsRepository { get; }
    }
}