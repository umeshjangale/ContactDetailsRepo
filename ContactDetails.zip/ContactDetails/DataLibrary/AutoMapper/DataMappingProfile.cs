﻿using AutoMapper;
using Data.Entities.Entity;
using Data.Models.Models;

namespace DataLibrary.AutoMapper
{
    public class DataMappingProfile : Profile
    {
        public DataMappingProfile()
        {
            CreateMap<ContactEntity, Contacts>()
                .ForMember(des => des.FirstName, obj => obj.MapFrom(src => src.FirstName))
                .ForMember(des => des.LastName, obj => obj.MapFrom(src => src.LastName))
                .ForMember(des => des.Email, obj => obj.MapFrom(src => src.Email))
                .ForMember(des => des.PhoneNumber, obj => obj.MapFrom(src => src.PhoneNumber))
                .ForMember(des => des.Status, obj => obj.MapFrom(src => src.Status))
                .ForMember(des => des.Id, obj => obj.MapFrom(src => src.Id))
                .ReverseMap();
        }
    }
}