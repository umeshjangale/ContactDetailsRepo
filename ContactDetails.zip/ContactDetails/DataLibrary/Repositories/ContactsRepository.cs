﻿using AutoMapper;
using Data.Models.Models;
using DataLibrary.Contracts;

namespace DataLibrary.Repositories
{
    public class ContactsRepository : RepositoryBase<Contacts>, IContactsRepository
    {
        private readonly ContactDbContext contactDbContext;
        private readonly IMapper mapper;

        public ContactsRepository(ContactDbContext contactDbContext, IMapper mapper) : base(contactDbContext, mapper)
        {
            this.contactDbContext = contactDbContext;
            this.mapper = mapper;
        }
    }
}