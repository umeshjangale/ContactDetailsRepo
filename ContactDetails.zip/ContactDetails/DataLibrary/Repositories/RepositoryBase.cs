﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataLibrary.Repositories
{
    public abstract class RepositoryBase<T> where T : class
    {
        private readonly DbSet<T> dbSet;
        public ContactDbContext DbContext { get; private set; }
        internal IMapper Mapper { get; private set; }

        protected RepositoryBase(ContactDbContext dbContext, IMapper mapper)
        {
            DbContext = dbContext;
            dbSet = DbContext.Set<T>();
            Mapper = mapper;
        }

        public virtual async Task<T> AddAsync(T entity)
        {
            await dbSet.AddAsync(entity);
            return entity;
        }
        public virtual async Task AddRange(List<T> entities)
        {
            await dbSet.AddRangeAsync(entities);
        }

        public virtual Task Update(T entity)
        {
            dbSet.Attach(entity);
            DbContext.Entry(entity).State = EntityState.Modified;
            return Task.CompletedTask;
        }

        public virtual Task Delete(T entity)
        {
            dbSet.Remove(entity);
            return Task.CompletedTask;
        }

        public virtual async Task<T> GetByIdAsync(object id)
        {
            return await dbSet.FindAsync(id);
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync()
        {
            return await dbSet.ToListAsync();
        }
    }
}