﻿using Data.Models.Models;

namespace DataLibrary.Contracts
{
    public interface IContactsRepository : IRepository<Contacts>
    {
    }
}