﻿using Data.Models.Models;
using Microsoft.EntityFrameworkCore;

namespace DataLibrary
{
    public class ContactDbContext : DbContext
    {
        public ContactDbContext(DbContextOptions<ContactDbContext> dbContext) : base(dbContext)
        {
        }

        public DbSet<Contacts> Contacts { get; set; }
    }
}