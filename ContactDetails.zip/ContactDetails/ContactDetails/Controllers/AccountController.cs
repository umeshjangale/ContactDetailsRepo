﻿using AutoMapper;
using Data.Entities.Entity;
using Data.Services.Contracts;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ContactDetails.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IContactService contactService;
        private readonly IMapper mapper;

        public AccountController(IContactService contactService, IMapper mapper)
        {
            this.contactService = contactService;
            this.mapper = mapper;
        }

        [HttpPost]
        [Route("authenticate")]
        public async Task<bool> Authenticate(AuthEntity authEntity)
        {
            return await contactService.AuthenticateAsync(authEntity);
        }

        [HttpPost]
        [Route("addupdatecontact")]
        public async Task<bool> AddUpdateContact(ContactEntity contactEntity)
        {
            return await contactService.AddUpdateContactsAsync(contactEntity);
        }

        [HttpGet]
        [Route("deletecontact")]
        public async Task<bool> DeleteContact(int id)
        {
            return await contactService.DeleteContactsAsync(id);
        }

        [HttpGet]
        [Route("getcontacts")]
        public async Task<IEnumerable<ContactEntity>> GetContacts()
        {
            return await contactService.GetAllContactsAsync();
        }

        [HttpGet]
        [Route("getcontactbyid")]
        public async Task<ContactEntity> GetContactById(int id)
        {
            return await contactService.GetByIdAsync(id);
        }
    }
}