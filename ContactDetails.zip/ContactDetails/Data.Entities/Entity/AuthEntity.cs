﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Entities.Entity
{
    public class AuthEntity
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
