﻿using Data.Entities.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Data.Services.Contracts
{
    public interface IContactService
    {
        Task<IEnumerable<ContactEntity>> GetAllContactsAsync();

        Task<ContactEntity> GetByIdAsync(int Id);

        Task<bool> AddUpdateContactsAsync(ContactEntity contacts);

        Task<bool> AuthenticateAsync(AuthEntity authEntity);

        Task<bool> DeleteContactsAsync(int id);
    }
}