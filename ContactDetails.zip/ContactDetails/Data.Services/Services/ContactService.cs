﻿using AutoMapper;
using Data.Entities.Entity;
using Data.Models.Models;
using Data.Services.Contracts;
using DataLibrary.UnitOfWork;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Data.Services.Services
{
    public class ContactService : IContactService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IMapper mapper;

        public ContactService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            this.unitOfWork = unitOfWork;
            this.mapper = mapper;
        }

        public async Task<bool> AuthenticateAsync(AuthEntity authEntity)
        {
            if (authEntity.UserName == "Admin" && authEntity.Password == "Admin")
                return true;

            return false;
        }

        public async Task<IEnumerable<ContactEntity>> GetAllContactsAsync()
        {
            IEnumerable<Contacts> contacts = await unitOfWork.ContactsRepository.GetAllAsync();

            return mapper.Map<IEnumerable<Contacts>, IEnumerable<ContactEntity>>(contacts);
        }

        public async Task<ContactEntity> GetByIdAsync(int id)
        {
            Contacts contacts = await unitOfWork.ContactsRepository.GetByIdAsync(id);

            return mapper.Map<Contacts, ContactEntity>(contacts);
        }

        public async Task<bool> AddUpdateContactsAsync(ContactEntity contactEntity)
        {
            Contacts contacts = mapper.Map<ContactEntity, Contacts>(contactEntity);

            if (contacts.Id == 0)
                await unitOfWork.ContactsRepository.AddAsync(contacts);
            else
                await UpdateContactsAsync(contacts);

            await unitOfWork.SaveChangesAsync();
            return true;
        }

        private async Task UpdateContactsAsync(Contacts contacts)
        {
            await unitOfWork.ContactsRepository.Update(contacts);
        }

        public async Task<bool> DeleteContactsAsync(int id)
        {
            Contacts contacts = await unitOfWork.ContactsRepository.GetByIdAsync(id);

            await unitOfWork.ContactsRepository.Delete(contacts);
            await unitOfWork.SaveChangesAsync();
            return true;
        }
    }
}