﻿using Data.Services.Contracts;
using Data.Services.Services;
using DataLibrary.Contracts;
using DataLibrary.Repositories;
using DataLibrary.UnitOfWork;
using Microsoft.Extensions.DependencyInjection;

namespace Data.Services
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection AddServices(this IServiceCollection services) =>
            services
                .AddTransient<IContactService, ContactService>()
                .AddTransient<IUnitOfWork, UnitOfWork>();


        public static IServiceCollection AddRepositories(this IServiceCollection services) =>
            services
                .AddTransient<IContactsRepository, ContactsRepository>();
    }
}